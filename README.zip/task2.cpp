
// task2.cpp
// Multithreaded C++ program that shares and decreases a variable from 20 down to 1 among 12 threads.
// Compile: g++ -std=c++17 -pthread -O2 -o task2 task2.cpp
#include <iostream>
#include <thread>
#include <vector>
#include <atomic>
#include <mutex>
#include <chrono>

int main() {
    const int THREADS = 12;
    std::atomic<int> value(20); // shared value to be decreased from 20 down to 1
    std::mutex io_mtx;

    auto worker = [&](int id) {
        while (true) {
            int prev = value.fetch_sub(1, std::memory_order_acq_rel);
            // fetch_sub returns previous value before decrement
            if (prev <= 0) {
                // someone already consumed final or underflowed; stop
                break;
            }
            {
                std::lock_guard<std::mutex> lk(io_mtx);
                std::cout << "Thread " << id << " decreased value to " << (prev - 1) << "\n";
            }
            if (prev - 1 <= 1) {
                // stop once value reached 1
                break;
            }
            // optional short sleep to allow other threads to run (not required)
            std::this_thread::sleep_for(std::chrono::milliseconds(10));
        }
    };

    std::vector<std::thread> threads;
    for (int i = 0; i < THREADS; ++i) {
        threads.emplace_back(worker, i);
    }

    for (auto &t : threads) if (t.joinable()) t.join();

    std::cout << "Final shared value = " << value.load() << "\n";
    return 0;
}
